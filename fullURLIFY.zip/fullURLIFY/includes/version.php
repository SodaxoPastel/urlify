<?php
/**
 * YOURLS version
 *
 */
define( 'YOURLS_VERSION', '1.7.10' );

/**
 * YOURLS DB version. Increments when changes are made to the DB schema, to trigger a DB update
 *
 */
define( 'YOURLS_DB_VERSION', '505' );
